#include "sjk.h"
#include "ui_sjk.h"


sjk::sjk(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::sjk)
{
    ui->setupUi(this);

    // 设置背景图片
    QPalette PAllbackground = this->palette();
    QImage ImgAllbackground(":/2.png");
    QImage fitimgpic = ImgAllbackground.scaled(this->width(), this->height(), Qt::IgnoreAspectRatio);
    PAllbackground.setBrush(QPalette::Window, QBrush(fitimgpic));
    this->setPalette(PAllbackground);

    // 数据库连接
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("localhost");
    db.setPort(3306);
    db.setUserName("root");
    db.setPassword("root");
    db.setDatabaseName("bms");

    if (db.open()) {
        qDebug() << "数据库连接成功";
    } else {
        qDebug() << "数据库连接失败：" << db.lastError();
        return;
    }

    // 验证码初始化
    captchaLabel = ui->captchaLabel;
    captchaInput = ui->captchaInput;

    // 绑定按钮功能
    connect(ui->refreshCaptchaButton, &QPushButton::clicked, this, &sjk::generateCaptcha);
    connect(ui->butlogin, &QPushButton::clicked, this, &sjk::validateCaptcha);

    // 初始生成验证码
    generateCaptcha();
}

sjk::~sjk()
{
    delete ui;
}

void sjk::generateCaptcha()
{
    captchaCode.clear();
    QString characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (int i = 0; i < 5; ++i) {
        int index = QRandomGenerator::global()->bounded(characters.size());
        captchaCode.append(characters.at(index));
    }

    QPixmap pixmap(150, 50);
    pixmap.fill(Qt::white);

    QPainter painter(&pixmap);
    QFont font = painter.font();
    font.setPointSize(18);
    painter.setFont(font);

    painter.setPen(Qt::blue);
    painter.drawText(pixmap.rect(), Qt::AlignCenter, captchaCode);

    painter.setPen(Qt::red);
    for (int i = 0; i < 5; ++i) {
        int x1 = QRandomGenerator::global()->bounded(150);
        int y1 = QRandomGenerator::global()->bounded(50);
        int x2 = QRandomGenerator::global()->bounded(150);
        int y2 = QRandomGenerator::global()->bounded(50);
        painter.drawLine(x1, y1, x2, y2);
    }

    painter.end();
    captchaLabel->setPixmap(pixmap);
}

void sjk::validateCaptcha()
{
    QString userInput = captchaInput->text();
    if (userInput == captchaCode) {
        QMessageBox::information(this, "验证码", "验证通过！");
    } else {
        QMessageBox::warning(this, "验证码", "验证码错误，请重试！");
        generateCaptcha(); // 重新生成验证码
    }
}
//注册按键
void sjk::on_butregister_clicked()
{
    // 校验验证码
    QString userInput = captchaInput->text();
    if (userInput != captchaCode) {
        QMessageBox::warning(this, "注册失败", "验证码错误，请重试！");
        generateCaptcha(); // 重新生成验证码
        return;
    }

    QSqlQuery query(db);
    bool register_flag = true;
    QString sno1 = ui->sno->text();
    QString username = ui->username->text();
    QString password = ui->password->text();
    if (sno1.isEmpty() || username.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "注册失败", "学号、姓名或密码不能为空！");
        return;
    }

    // 检查学号和姓名是否匹配
    QString checkSql = QString("SELECT * FROM student WHERE S_ID = '%1' AND S_NAME = '%2';").arg(sno1).arg(username);
    if (!query.exec(checkSql) || !query.next()) {
        QMessageBox::information(this, "注册失败", "学号和姓名不匹配！");
        qDebug() << "学号和姓名不匹配：" << query.lastError();
        register_flag = false;
        return;
    }

    // 检查用户是否已存在
    QString checkExistSql = QString("SELECT * FROM logindata WHERE S_ID = '%1' AND S_NAME = '%2';").arg(sno1).arg(username);
    if (query.exec(checkExistSql) && query.next()) {
        QMessageBox::warning(this, "注册失败", "用户已存在");
        qDebug() << "用户已存在";
        register_flag = false;
        return;
    }

    // 插入新用户
    if (register_flag == true) {
        QString sql2 = QString("INSERT INTO login (S_ID, S_NAME, S_PASSWD) VALUES ('%1', '%2', '%3');").arg(sno1).arg(username).arg(password);

        if (query.exec(sql2)) {
            QMessageBox::information(this, "注册成功", "欢迎！");
            qDebug() << "登录数据插入成功";
        } else {
            qDebug() << "登录数据插入失败：" << query.lastError();
            QMessageBox::critical(this, "注册失败", "用户已存在!!!。");
        }
    }
}


// 登录按钮点击
void sjk::on_butlogin_clicked()
{
    // 校验验证码
    QString userInput = captchaInput->text();
    if (userInput != captchaCode) {
        QMessageBox::warning(this, "登录失败", "验证码错误，请重试！");
        generateCaptcha(); // 重新生成验证码
        return;
    }

    QSqlQuery query(db);
    QString sql = "SELECT * FROM login;";
    if (query.exec(sql)) {
        qDebug() << "查询成功";
    } else {
        qDebug() << "查询失败：" << query.lastError();
        return; // 如果查询失败，则不继续执行
    }

    QString sno = ui->sno->text();
    QString username = ui->username->text();
    QString password = ui->password->text();

    bool loginSuccess = false;
    bool adminlogin = false;

    if (usr_mode == 0) { // 学生登录
        if (sno.isEmpty() || username.isEmpty() || password.isEmpty()) {
            QMessageBox::warning(this, "登录失败", "学号、姓名或密码不能为空！");
            return;
        }
        while (query.next()) {
            QString lo_sno = query.value(0).toString();
            QString lo_name = query.value(1).toString();
            QString lo_password = query.value(2).toString();

            if (sno == lo_sno && username == lo_name && password == lo_password) {
                loginSuccess = true;
                break;
            }
        }
        if (loginSuccess) {
            qDebug() << "登录成功";
            QMessageBox::information(this, "登录成功", "欢迎登录！");
            s_book *b = new s_book(db, sno);
            b->show();  // 显示新界面
            this->hide();  // 隐藏当前界面
            connect(b, &s_book::destroyed, this, &sjk::show);
            this->close();
        } else {
            qDebug() << "登录失败，请注册或检查用户名和密码";
            QMessageBox::warning(this, "登录失败", "用户名或密码错误，请重新输入或注册！");
        }
    } else if (usr_mode == 1) { // 管理员登录
        QString sqlAdmin = "SELECT * FROM admin;";
        if (!query.exec(sqlAdmin)) {
            qDebug() << "管理员查询失败：" << query.lastError();
            return;
        }

        while (query.next()) {
            QString adminName = query.value(2).toString();
            QString adminPwd = query.value(3).toString();

            if (username == adminName && password == adminPwd) {
                adminlogin = true;
                break;
            }
        }

        if (adminlogin) {
            qDebug() << "管理员登录成功";
            QMessageBox::information(this, "管理员登录成功", "欢迎登录！");
            admin *ad = new admin(db);
            ad->show();
            this->hide();
            connect(ad, &admin::destroyed, this, &sjk::show);
            this->close();
        } else {
            qDebug() << "管理员登录失败，请检查用户名和密码";
            QMessageBox::warning(this, "登录失败", "用户名或密码错误，请重新输入或注册！");
        }
    }
}



void sjk::on_usr_switch_currentTextChanged(const QString &arg1)
{
    if(arg1=="管理员"){
        ui->sno->setReadOnly(true);
        ui->sno->clear();
        ui->butregister->setEnabled(0);
        usr_mode=true;
    }
    if(arg1=="学生"){
        ui->sno->setReadOnly(false);
        ui->butregister->setEnabled(1);
        usr_mode=false;
    }
}
