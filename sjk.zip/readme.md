基于qt5.0和MySQL的图书管理系统
在![PixPin_2024-12-20_09-55-18](https://github.com/user-attachments/assets/746add88-ad37-487d-a77f-462b0914c705)
更改数据库密码
多样主题选择
![PixPin_2024-12-20_09-56-13](https://github.com/user-attachments/assets/eb1f04e5-36b0-487e-90d2-e86032fec588)
在main进行更改
![PixPin_2024-12-20_09-56-52](https://github.com/user-attachments/assets/91a6bb37-1c4d-459c-b351-67368a26c8a7)