#ifndef SJK_H
#define SJK_H

#include <QWidget>
#include <QSqlDatabase>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QMessageBox>
#include "s_book.h"
#include "admin.h"
#include <QRandomGenerator>
#include <QPainter>

namespace Ui {
class sjk;
}

class sjk : public QWidget
{
    Q_OBJECT

public:
    explicit sjk(QWidget *parent = nullptr);
    ~sjk();
    bool usr_mode=0;
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");


private slots:
    void on_butregister_clicked();

    void on_butlogin_clicked();

    void on_usr_switch_currentTextChanged(const QString &arg1);

    void generateCaptcha(); // 生成验证码
    void validateCaptcha(); // 校验验证码
private:
    Ui::sjk *ui;
    QString captchaCode;    // 存储生成的验证码
    QLabel *captchaLabel;   // 显示验证码
    QLineEdit *captchaInput; // 输入验证码的文本框
};

#endif // SJK_H
